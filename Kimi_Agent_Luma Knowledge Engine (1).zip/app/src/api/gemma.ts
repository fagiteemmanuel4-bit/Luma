const GEMMA_API_KEY = import.meta.env.VITE_GEMMA_API_KEY || '';
const GEMMA_MODEL = import.meta.env.VITE_GEMMA_MODEL || 'gemma-4-27b-it';

export async function synthesizeAnswer(query: string, apiData: any, readingLevel: string) {
  try {
    const levelPrompt = readingLevel === 'simple'
      ? 'Respond as if explaining to a 12-year-old. Short sentences. No jargon. Use analogies.'
      : readingLevel === 'technical'
      ? 'Respond for a domain expert. Include precise terminology, cite mechanisms, don\'t simplify.'
      : 'Respond for a general educated adult audience. Clear, concise, informative.';

    const systemPrompt = `You are Luma, a universal knowledge synthesizer. You receive a user query and raw data pulled from multiple open APIs simultaneously. Synthesize a structured response:
1) One-paragraph Summary (max 80 words)
2) 3-5 Key Facts (bullet, cited by source name)
3) What This Means (practical implication, 2 sentences)
4) 2 Further Reading suggestions from the provided sources.
${levelPrompt}
Respond in the same language as the query.
Never fabricate. If data is absent, say so honestly.`;

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000);

    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${GEMMA_MODEL}:generateContent?key=${GEMMA_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [
            { role: 'user', parts: [{ text: systemPrompt }] },
            { role: 'model', parts: [{ text: 'Understood. I am Luma, ready to synthesize knowledge from the provided API data.' }] },
            { role: 'user', parts: [{ text: `QUERY: ${query}\n\nRAW API DATA:\n${JSON.stringify(apiData, null, 2)}` }] },
          ],
          generationConfig: {
            temperature: 0.3,
            maxOutputTokens: 1024,
          },
        }),
        signal: controller.signal,
      }
    );
    clearTimeout(timeoutId);

    const data = await res.json();
    
    if (data.error) {
      throw new Error(data.error.message);
    }

    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    return text;
  } catch (e) {
    console.error('Gemma synthesis error:', e);
    return generateFallbackAnswer(query, apiData, readingLevel);
  }
}

function generateFallbackAnswer(query: string, apiData: any, readingLevel: string) {
  const sources = Object.keys(apiData).filter(k => apiData[k]);
  const level = readingLevel === 'simple' ? 'simple terms' : readingLevel === 'technical' ? 'technical detail' : 'clear, informative language';
  
  return `## Summary\n\nBased on data from ${sources.length} sources, here's what we found about "${query}":\n\n` +
    sources.map(s => `- ${s}: Data available`).join('\n') + 
    `\n\n## What This Means\n\nThis information has been gathered from multiple open knowledge sources. Please verify critical details with primary sources.\n\n## Further Reading\n\n- Explore the original sources linked above for more detail.`;
}
